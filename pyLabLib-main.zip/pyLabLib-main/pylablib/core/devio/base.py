class DeviceError(RuntimeError):
    """Generic device communication error"""