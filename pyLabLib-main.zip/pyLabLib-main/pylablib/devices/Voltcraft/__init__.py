from .base import GenericVoltcraftError, GenericVoltcraftBackendError
from .multimeter import VC7055, VC880