from .base import NewportError
from .picomotor import Picomotor8742, get_usb_devices_number as get_usb_devices_number_picomotor