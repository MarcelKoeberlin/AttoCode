from .ibeam import TopticaIBeam
from .base import TopticaError