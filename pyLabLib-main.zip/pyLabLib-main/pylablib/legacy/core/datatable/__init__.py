from . import table as datatable
from .table import DataTable

from . import column
from .column import as_column, crange